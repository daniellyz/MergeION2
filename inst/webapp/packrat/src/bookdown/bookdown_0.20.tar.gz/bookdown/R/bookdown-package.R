#' Authoring Books and Technical Documents with R Markdown
#'
#' A open-source (GPL-3) R package to facilitate writing books and long-form
#' articles/reports with R Markdown.
#' @keywords internal
"_PACKAGE"
