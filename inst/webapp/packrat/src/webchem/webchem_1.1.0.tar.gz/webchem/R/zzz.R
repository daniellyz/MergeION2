.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Help us improve the package")
  packageStartupMessage("Fill out our 2020 survey at https://forms.gle/V7dfGGn73dkesn5L6")
}