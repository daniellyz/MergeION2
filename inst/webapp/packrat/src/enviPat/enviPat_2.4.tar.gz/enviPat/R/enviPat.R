.onAttach <- function(lib, pkg)
{
	packageStartupMessage(paste("\n \n Welcome to enviPat version 2.4 \n Check www.envipat.eawag.ch for an interactive online version\n",sep=""));

}
