getURL("https://stat.ethz.ch", cainfo = "ca-bundle.crt")
