library(testthat)
library(AhoCorasickTrie)

test_check("AhoCorasickTrie")
