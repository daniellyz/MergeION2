library("testthat")
test_check("MALDIquant")
