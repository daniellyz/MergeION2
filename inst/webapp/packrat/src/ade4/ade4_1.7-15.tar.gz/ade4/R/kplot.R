"kplot" <- function (object, ...) {
    UseMethod("kplot")
}
